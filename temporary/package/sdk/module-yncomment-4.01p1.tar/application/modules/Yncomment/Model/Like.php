<?php
class Yncomment_Model_Like extends Core_Model_Like
{
  protected $_searchTriggers = false;
}