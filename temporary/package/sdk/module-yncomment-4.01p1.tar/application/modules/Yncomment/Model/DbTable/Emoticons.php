<?php
class Yncomment_Model_DbTable_Emoticons extends Engine_Db_Table
{
}
?>
