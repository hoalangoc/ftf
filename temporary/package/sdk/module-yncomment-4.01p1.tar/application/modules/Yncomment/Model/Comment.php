<?php
class Yncomment_Model_Comment extends Core_Model_Comment {
    protected $_searchTriggers = false;
}