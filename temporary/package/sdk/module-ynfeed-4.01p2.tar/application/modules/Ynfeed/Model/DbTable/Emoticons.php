<?php
class Ynfeed_Model_DbTable_Emoticons extends Engine_Db_Table
{
}
?>
