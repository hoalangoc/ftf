<?php
class Ynfeed_Model_Customtype extends Core_Model_Item_Abstract {

	protected $_searchTriggers = false;
	protected $_modifiedTriggers = false;
}
