<?php
class Ynfeed_Model_ListItem extends Core_Model_ListItem {

  protected $_searchTriggers = false;
  protected $_modifiedTriggers = false;

}
