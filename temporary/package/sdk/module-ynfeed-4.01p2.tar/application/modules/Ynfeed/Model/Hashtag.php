<?php
class Ynfeed_Model_Hashtag extends Core_Model_Item_Abstract
{
	protected $_searchTriggers = false;
	protected $_modifiedTriggers = false;
}
?>
