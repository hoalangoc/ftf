<?php
class Ynfeed_Model_Welcome extends Core_Model_Item_Abstract {

	protected $_searchTriggers = false;
	protected $_modifiedTriggers = false;
}
