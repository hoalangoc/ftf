<?php
class Ynfeed_Model_DbTable_ListItems extends Engine_Db_Table {

  protected $_rowClass = 'Ynfeed_Model_ListItem';

}